import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Stretovych Tymur
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Choose mode: 1 (from files) or 2 (from console)");
        Scanner scanner = new Scanner(System.in);
        int mode_choice = scanner.nextInt();

        Tensor tensor1 = new Tensor();

        if (mode_choice == 1){
            String filename1 = "inputs/input1.txt";
            tensor1.readFromFile(filename1);
        }
        else{
            tensor1.readFromConsole();
        }
        System.out.println("Tensor1:");
        tensor1.print();
        System.out.println("Tensor[2,1,1] elem:" + tensor1.getElem(new int[]{1, 0, 0}));
        tensor1.printToTxtFile("output.txt");

        System.out.println("\nRead/Write Tensor2 from/to JSON:");
        Tensor tensor_json = new Tensor();
        tensor_json.readFromJSON("input2.json");
        tensor_json.writeToJSON("output2.json");

        System.out.println("\nRead/Write Tensor1 from/to XML:");
        Tensor tensor_xml = new Tensor();
        tensor_xml.readFromXML("input1.xml");
        tensor_xml.writeToXML("output1.xml");


        System.out.println("\nTensor3 multiplying by scalar:");
        Tensor tensor3 = new Tensor();
        String filename3 = "inputs/input3.txt";
        tensor3.readFromFile(filename3);
        tensor3.tensorScalarMultiplication(2);
        tensor3.print();

        System.out.println("Transposing:");
        System.out.println("Original Tensor4:");
        Tensor tensor4 = new Tensor();
        String filename4 = "inputs/input4.txt";
        tensor4.readFromFile(filename4);
        tensor4.print();
        System.out.println("Transpose Tensor4:");
        tensor4.transpon().print();


        System.out.println("Multiplying Tensor4 and Tensor5:");
        System.out.println("Original Tensor4:");
        tensor4.print();
        System.out.println("Original Tensor5:");
        Tensor tensor5 = new Tensor();
        String filename5 = "inputs/input5.txt";
        tensor5.readFromFile(filename5);
        tensor5.print();
        System.out.println("Tensor4 * Tensor5:");
        tensor4.multTensor(tensor5).print();

        System.out.println("Adding Tensor4 and Tensor5:");
        System.out.println("Tensor4 + Tensor5:");
        tensor4.addTensor(tensor5).print();

        System.out.println("Subtraction Tensor4 and Tensor5:");
        System.out.println("Tensor4 - Tensor5:");
        tensor4.subTensor(tensor5).print();

        // UPD (more tests)
        System.out.println("Let's show more test inputs:");

        System.out.println("\nTensor6  dim=(4;3;2):");
        Tensor tensor6 = new Tensor();
        tensor6.readFromFile("inputs/input6.txt");
        tensor6.print();
        System.out.println("\nTensor6 multiplying by scalar 0:");
        tensor6.tensorScalarMultiplication(0);
        tensor6.print();

        System.out.println("\nTensor7  dim=(1,1,1,1,1):");
        Tensor tensor7 = new Tensor();
        tensor7.readFromFile("inputs/input7.txt");
        tensor7.print();
        System.out.println("\nTensor7 transpose:");
        tensor7.transpon().print();

        System.out.println("\nTensor8  dim=(5,10,10):");
        Tensor tensor8 = new Tensor();
        tensor8.readFromFile("inputs/input8.txt");
        tensor8.print();

        System.out.println("\nTensor9  dim=(5,10,10):");
        Tensor tensor9 = new Tensor();
        tensor9.readFromFile("inputs/input9.txt");
        tensor9.print();

        System.out.println("Tensor8 + Tensor9:");
        tensor8.addTensor(tensor9).print();

        System.out.println("\nTensor10  dim=(3,4,5,5,6):");
        Tensor tensor10 = new Tensor();
        tensor10.readFromFile("inputs/input10.txt");
        tensor10.print();

        System.out.println("\nTensor11  dim=(3,4,5,5,6):");
        Tensor tensor11 = new Tensor();
        tensor11.readFromFile("inputs/input11.txt");
        tensor11.print();

        System.out.println("\nTensor10 * Tensor11:");
        tensor10.multTensor(tensor11).print();

        System.out.println("\nTensor12  dim=(20,1):");
        Tensor tensor12 = new Tensor();
        tensor12.readFromFile("inputs/input12.txt");
        tensor12.print();

        System.out.println("\nTensor13  dim=(1,20):");
        Tensor tensor13 = new Tensor();
        tensor13.readFromFile("inputs/input13.txt");
        tensor13.print();

        System.out.println("\nTensor14  dim=(1,2,1,2,1,2,1,2,1,2,1):");
        Tensor tensor14 = new Tensor();
        tensor14.readFromFile("inputs/input14.txt");
        tensor14.print();

        System.out.println("\nTensor15  dim=(3,3,3):");
        Tensor tensor15 = new Tensor();
        tensor15.readFromFile("inputs/input15.txt");
        tensor15.print();

    }
}