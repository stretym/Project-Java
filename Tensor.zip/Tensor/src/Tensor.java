import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import java.io.*;
import java.util.*;

/**
 * @author Stretovych Tymur
 */
public class Tensor{
    private int[] dimensions;
    private double[] data;

    /**
     * Constructs a tensor with given dimensions and data.
     *
     * @param dimensions the dimensions of the tensor
     * @param data       the data values of the tensor
     */
    public Tensor(int[] dimensions, double[] data) {
        this.dimensions = dimensions;
        this.data = data;
    }

    /**
     * Default constructor for Tensor.
     */
    public Tensor() {
    }

    /**
     * Retrieves the data values of the tensor.
     *
     * @return an array containing the data of the tensor
     */
    public double[] getData(){
        return Arrays.copyOf(data, data.length);
    }

    /**
     * Retrieves the dimensions of the tensor.
     *
     * @return an array containing the dimensions of the tensor
     */
    public int[] getDimensions(){
        return Arrays.copyOf(dimensions, dimensions.length);
    }

    /**
     * Writes the tensor data to an XML file.
     *
     * @param filename the name of the XML file to write
     */
    public void writeToXML(String filename) {
        XmlMapper xmlMapper = new XmlMapper();
        try {
            Map<String, Object> tensorMap = new HashMap<>();
            tensorMap.put("dimensions", dimensions);
            tensorMap.put("data", data);

            xmlMapper.writeValue(new File(filename), tensorMap);
            System.out.println("XML data has been written to " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads tensor data from an XML file.
     *
     * @param filename the name of the XML file to read from
     */
    public void readFromXML(String filename) {
        XmlMapper xmlMapper = new XmlMapper();
        try {
            Map<String, Object> tensorMap = xmlMapper.readValue(new File(filename), Map.class);

            ArrayList<?> dimensionsList = (ArrayList<?>) tensorMap.get("dimensions");
            dimensions = dimensionsList.stream()
                    .mapToInt(obj -> Integer.parseInt(obj.toString()))
                    .toArray();

            ArrayList<?> dataList = (ArrayList<?>) tensorMap.get("data");
            data = new double[dataList.size()];
            for (int i = 0; i < dataList.size(); i++) {
                data[i] = Double.parseDouble(dataList.get(i).toString());
            }

            System.out.println("Tensor data has been read from " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Writes the tensor data to a JSON file.
     *
     * @param filename the name of the JSON file to write
     */
    public void writeToJSON(String filename) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Map<String, Object> tensorMap = new HashMap<>();
            tensorMap.put("dimensions", dimensions);
            tensorMap.put("data", data);
            objectMapper.writeValue(new File(filename), tensorMap);
            System.out.println("JSON data has been written to " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads tensor data from a JSON file.
     *
     * @param filename the name of the JSON file to read from
     */
    public void readFromJSON(String filename) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            Map<String, Object> tensorMap = objectMapper.readValue(new File(filename),
                    Map.class);

            ArrayList<Integer> dimensionsList = (ArrayList<Integer>) tensorMap.get("dimensions");
            dimensions = dimensionsList.stream().mapToInt(Integer::intValue).toArray();

            ArrayList<Double>  dataList = (ArrayList<Double>) tensorMap.get("data");
            data = new double[dataList.size()];
            for (int i = 0; i < dataList.size(); i++) {
                data[i] = dataList.get(i);
            }
            System.out.println("Tensor data has been read from " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Prints the tensor data in console.
     */
    public void print() {
        int[] pointer = new int[dimensions.length];
        int dataIndex = 0;
        while (dataIndex < data.length) {
            System.out.print(data[dataIndex++] + " ");
            pointer[0]++;
            for (int j = 0; j < dimensions.length - 1; j++) {
                if (pointer[j] == dimensions[j]) {
                    pointer[j] = 0;
                    pointer[j + 1]++;
                    System.out.println();
                }
            }
        }
    }

    /**
     * Prints tensor data to a text file.
     *
     * @param filename the name of the text file to write
     */
    public void printToTxtFile(String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            int[] pointer = new int[dimensions.length];
            int dataIndex = 0;
            while (dataIndex < data.length) {
                writer.write(data[dataIndex] + " ");
                dataIndex++;
                pointer[0]++;
                for (int j = 0; j < dimensions.length - 1; j++) {
                    if (pointer[j] == dimensions[j]) {
                        pointer[j] = 0;
                        pointer[j + 1]++;
                        writer.newLine();
                    }
                }
            }
            System.out.println("Tensor data has been printed to " + filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves an element from the tensor at a specified position.
     *
     * @param pos the position of the element to retrieve
     * @return the element at the specified position
     */
    public double getElem(int[] pos) {
        int[] tmp = new int[pos.length];
        System.arraycopy(pos, 0, tmp, 0, pos.length);
        for(int i = pos.length-1; i >= 0; i--){
            pos[pos.length-1-i] = tmp[i];
        }
        int pointer = 0;
        int len = data.length;
        for (int i = pos.length-1; i >= 0; i--) {
            pointer += ((double) pos[i] / dimensions[i]) * len;
            len /= dimensions[i];
        }
        return data[pointer];
    }

    /**
     * Performs scalar multiplication on the tensor.
     *
     * @param scalar the scalar value to multiply the tensor with
     */
    public void tensorScalarMultiplication(double scalar) {
        for(int i = 0; i < data.length; i++){
            data[i] *= scalar;
        }
    }

    /**
     * Reads tensor data from the console.
     */
    public void readFromConsole() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of tensor dimensions (start from deepest):");
        int n = scanner.nextInt();
        int number = 1;
        dimensions = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Enter " + (i + 1) + "-th dimension size:");
            dimensions[n - 1 - i] = scanner.nextInt();
            number *= dimensions[n - 1 - i];
        }
        data = new double[number];
        System.out.println("Enter tensor:");
        for (int i = 0; i < number; i++) {
            data[i] = scanner.nextDouble();
        }
    }

    /**
     * Reads tensor data from a file.
     *
     * @param fileName the name of the file to read from
     * @throws FileNotFoundException if the file is not found
     */
    public void readFromFile(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        Scanner scanner = new Scanner(file);
        int n = scanner.nextInt();
        int number = 1;
        dimensions = new int[n];
        for (int i = 0; i < n; i++) {
            dimensions[n - 1 - i] = scanner.nextInt();
            number *= dimensions[n - 1 - i];
        }
        data = new double[number];
        for (int i = 0; i < number; i++) {
            data[i] = scanner.nextDouble();
        }
    }

    /**
     * Adds another tensor to this tensor.
     *
     * @param tensorAdd the tensor to add
     * @return the resulting tensor after addition
     */
    public Tensor addTensor(Tensor tensorAdd){
        Tensor result = new Tensor(tensorAdd.getDimensions(), tensorAdd.getData());
        double[] addData = tensorAdd.getData();
        for(int i = 0; i < data.length; i++){
            result.data[i] = data[i] + addData[i];
        }
        return result;
    }

    /**
     * Subtracts another tensor from this tensor.
     *
     * @param tensorSub the tensor to subtract
     * @return the resulting tensor after subtraction
     */
    public Tensor subTensor(Tensor tensorSub){
        Tensor result = new Tensor(tensorSub.getDimensions(), tensorSub.getData());
        double[] subData = tensorSub.getData();
        for(int i = 0; i < data.length; i++){
            result.data[i] = data[i] - subData[i];
        }
        return result;
    }

    /**
     * Transposes the tensor.
     *
     * @return the transposed tensor
     */
    public Tensor transpon(){
        double[] tmp = new double[data.length];
        System.arraycopy(data, 0, tmp, 0, data.length);
        for(int i = data.length-1; i >= 0; i--){
            tmp[data.length-1-i] = data[i];
        }
        return new Tensor(dimensions, tmp);
    }

    /**
     * Multiplies this tensor with another tensor element-wise.
     *
     * @param tensorMult the tensor to multiply with
     * @return the resulting tensor after element-wise multiplication
     */
    public Tensor multTensor(Tensor tensorMult){
        Tensor tens = tensorMult.transpon();
        for(int i = 0; i < data.length; i++){
            tens.data[i] *= data[i];
        }
        return tens;
    }
}
